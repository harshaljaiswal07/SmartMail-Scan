// Global variables
let model;
let vectorizer;
let emailResults = [];
let spamEmailIds = [];
let spamDatabase = []; // Store spam patterns from spam.csv
let settings = {
    autoDelete: false,
    customKeywords: ['buy now', 'offer', 'discount', 'subscribe', 'promotion']
};

// Email scanning configuration
const EMAIL_CONFIG = {
    imap: {
        user: '', // Will be set from user input
        password: '', // Will be set from user input (app password)
        host: 'imap.gmail.com',
        port: 993,
        tls: true,
        tlsOptions: { 
            rejectUnauthorized: false,
            servername: 'imap.gmail.com'
        },
        debug: console.log // Enable IMAP debugging
    }
};

// Initialize email client
let emailClient = null;

// Store user credentials
let userCredentials = {
    email: '',
    appPassword: ''
};

// Initialize the application
document.addEventListener('DOMContentLoaded', async () => {
    await initializeModel();
    await loadSpamDatabase();
    setupEventListeners();
    loadSettings();
});

// Load spam database from spam.csv
async function loadSpamDatabase() {
    try {
        const response = await fetch('spam.csv');
        const csvText = await response.text();
        const lines = csvText.split('\n');
        
        // Skip header if exists and process each line
        for (let i = 1; i < lines.length; i++) {
            const line = lines[i].trim();
            if (line) {
                const parts = line.split(',');
                if (parts.length >= 2) {
                    const label = parts[0].replace(/"/g, '');
                    const text = parts[1].replace(/"/g, '');
                    if (label === 'spam' && text) {
                        spamDatabase.push(text.toLowerCase());
                    }
                }
            }
        }
        console.log(`Loaded ${spamDatabase.length} spam patterns from database`);
    } catch (error) {
        console.error('Error loading spam database:', error);
        showNotification('Warning: Could not load spam database', 'warning');
    }
}

// Initialize TensorFlow.js model
async function initializeModel() {
    try {
        // Load the pre-trained model (you'll need to convert and host your Python model)
        // For now, we'll use a simple rule-based approach
        showNotification('Model initialized successfully', 'success');
    } catch (error) {
        showNotification('Error initializing model: ' + error.message, 'error');
    }
}

// Setup event listeners
function setupEventListeners() {
    // Login form submission
    document.getElementById('loginForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        await scanInbox();
    });

    // Action buttons
    document.getElementById('markAsRead').addEventListener('click', markAsRead);
    document.getElementById('deleteSpam').addEventListener('click', deleteSpam);
    document.getElementById('exportCsv').addEventListener('click', exportToCsv);
    document.getElementById('saveSettings').addEventListener('click', saveSettings);

    // Settings
    document.getElementById('autoDelete').addEventListener('change', (e) => {
        settings.autoDelete = e.target.checked;
    });

    document.getElementById('customKeywords').addEventListener('change', (e) => {
        settings.customKeywords = e.target.value.split(',').map(k => k.trim());
    });
}

// Load settings from localStorage
function loadSettings() {
    const savedSettings = localStorage.getItem('spamDetectorSettings');
    if (savedSettings) {
        settings = JSON.parse(savedSettings);
        document.getElementById('autoDelete').checked = settings.autoDelete;
        document.getElementById('customKeywords').value = settings.customKeywords.join(', ');
    }
}

// Save settings to localStorage
function saveSettings() {
    localStorage.setItem('spamDetectorSettings', JSON.stringify(settings));
    showNotification('Settings saved successfully', 'success');
}

// Function to connect to Gmail using the Python backend
async function connectToGmail(email, appPassword) {
    try {
        const response = await fetch('http://localhost:5000/connect', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                email: email,
                app_password: appPassword
            })
        });

        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Failed to connect to Gmail');
        }

        // Store credentials for future use
        userCredentials.email = email;
        userCredentials.appPassword = appPassword;

        return true;
    } catch (error) {
        console.error('Connection error:', error);
        throw error;
    }
}

// Function to fetch unread emails
async function fetchUnreadEmails() {
    try {
        const response = await fetch('http://localhost:5000/scan', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                email: userCredentials.email,
                app_password: userCredentials.appPassword
            })
        });

        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Failed to fetch emails');
        }

        return data.emails;
    } catch (error) {
        console.error('Fetch error:', error);
        throw error;
    }
}

// Function to mark email as read
async function markEmailAsRead(emailId) {
    try {
        const response = await fetch('http://localhost:5000/mark-read', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                email: userCredentials.email,
                app_password: userCredentials.appPassword,
                email_id: emailId
            })
        });

        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Failed to mark email as read');
        }

        return true;
    } catch (error) {
        console.error('Mark as read error:', error);
        throw error;
    }
}

// Function to delete email
async function deleteEmail(emailId) {
    try {
        const response = await fetch('http://localhost:5000/delete', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                email: userCredentials.email,
                app_password: userCredentials.appPassword,
                email_id: emailId
            })
        });

        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Failed to delete email');
        }

        return true;
    } catch (error) {
        console.error('Delete error:', error);
        throw error;
    }
}

// Function to delete multiple emails
async function deleteMultipleEmails(emailIds) {
    try {
        const response = await fetch('http://localhost:5000/delete-multiple', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                email: userCredentials.email,
                app_password: userCredentials.appPassword,
                email_ids: emailIds
            })
        });

        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Failed to delete emails');
        }

        return true;
    } catch (error) {
        console.error('Delete multiple error:', error);
        throw error;
    }
}

// Main scanning function
async function scanInbox() {
    try {
        showLoading(true);
        showAlert('Scanning inbox for unread emails...', 'info');
        
        const emails = await fetchUnreadEmails();
        
        if (emails.length === 0) {
            showAlert('No unread emails found', 'info');
            hideLoading();
            return;
        }

        emailResults = [];
        spamEmailIds = [];
        
        showAlert(`Found ${emails.length} unread emails. Analyzing...`, 'info');
        
        // Process each email
        for (let i = 0; i < emails.length; i++) {
            const email = emails[i];
            updateProgress((i / emails.length) * 100, `Processing email ${i + 1} of ${emails.length}`);
            
            // Extract sender email from sender field
            const senderEmail = extractSenderEmail(email.sender);
            
            // Analyze email content
            const spamStatus = predictSpam(email.subject + ' ' + email.body);
            const adStatus = isAdEmail(email.body);
            const priority = determinePriority(email.subject, email.body);
            const category = determineCategory(email.subject, email.body);
            
            const processedEmail = {
                id: email.id,
                subject: email.subject,
                from: email.sender,
                senderEmail: senderEmail, // Add sender email
                date: email.date,
                body: email.body,
                spamStatus: spamStatus,
                adStatus: adStatus,
                priority: priority,
                category: category
            };
            
            emailResults.push(processedEmail);
            
            if (spamStatus === 'Spam' || adStatus === 'Ad') {
                spamEmailIds.push(email.id);
            }
        }
        
        hideProgress();
        refreshTable();
        
        // Show results
        const spamCount = emailResults.filter(e => e.spamStatus === 'Spam').length;
        const adCount = emailResults.filter(e => e.adStatus === 'Ad').length;
        
        showAlert(`Scan complete! Found ${spamCount} spam emails and ${adCount} ad emails out of ${emails.length} total emails.`, 'success');
        
        // Show delete buttons if spam/ad emails found
        if (spamEmailIds.length > 0) {
            showDeleteButtons();
        }
        
    } catch (error) {
        console.error('Scan error:', error);
        showAlert(error.message || 'Error scanning inbox', 'danger');
    } finally {
        hideLoading();
    }
}

// Extract sender email from sender field
function extractSenderEmail(sender) {
    try {
        // Common patterns for email extraction
        const emailPattern = /<([^>]+@[^>]+)>/;
        const simpleEmailPattern = /([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/;
        
        let match = sender.match(emailPattern);
        if (match) {
            return match[1];
        }
        
        match = sender.match(simpleEmailPattern);
        if (match) {
            return match[1];
        }
        
        return 'No email found';
    } catch (error) {
        console.error('Error extracting sender email:', error);
        return 'Error extracting email';
    }
}

// Enhanced spam prediction using spam database
function predictSpam(text) {
    const lowerText = text.toLowerCase();
    
    // Check against spam database
    for (const spamPattern of spamDatabase) {
        if (lowerText.includes(spamPattern)) {
            return 'Spam';
        }
    }
    
    // Check for common spam indicators
    const spamKeywords = [
        'free', 'winner', 'congratulations', 'claim', 'prize', 'lottery', 'urgent',
        'limited time', 'act now', 'click here', 'unsubscribe', 'viagra', 'casino',
        'loan', 'debt', 'credit', 'refinance', 'weight loss', 'diet', 'enlargement'
    ];
    
    const spamCount = spamKeywords.filter(keyword => 
        lowerText.includes(keyword)
    ).length;
    
    if (spamCount >= 2) {
        return 'Spam';
    }
    
    return 'Ham';
}

// Enhanced ad detection
function isAdEmail(body) {
    const lowerBody = body.toLowerCase();
    
    const adKeywords = [
        'buy now', 'offer', 'discount', 'subscribe', 'promotion', 'sale',
        'limited time', 'act now', 'click here', 'shop now', 'order now',
        'special offer', 'exclusive deal', 'save money', 'best price',
        'free shipping', 'money back', 'guarantee', 'satisfaction guaranteed'
    ];
    
    const adCount = adKeywords.filter(keyword => 
        lowerBody.includes(keyword)
    ).length;
    
    if (adCount >= 2) {
        return 'Ad';
    }
    
    return 'Not Ad';
}

// Refresh the email table
function refreshTable() {
    const tableBody = document.getElementById('emailTableBody');
    const emailTable = document.getElementById('emailTable');
    const emailCount = document.getElementById('emailCount');
    const exportButton = document.getElementById('exportButton');
    
    if (emailResults.length === 0) {
        emailTable.style.display = 'none';
        exportButton.style.display = 'none';
        emailCount.textContent = '0';
        return;
    }
    
    emailCount.textContent = emailResults.length;
    emailTable.style.display = 'table';
    exportButton.style.display = 'block';
    
    tableBody.innerHTML = '';
    
    emailResults.forEach(email => {
        const row = document.createElement('tr');
        row.setAttribute('data-email-id', email.id);
        
        row.innerHTML = `
            <td>
                <strong>${email.subject}</strong>
                <br><small class="text-muted">${email.senderEmail}</small>
            </td>
            <td>${email.from}</td>
            <td>${new Date(email.date).toLocaleString()}</td>
            <td>
                <span class="badge ${email.spamStatus === 'Spam' ? 'bg-danger' : 'bg-success'}">${email.spamStatus}</span>
                <span class="badge ${email.adStatus === 'Ad' ? 'bg-warning' : 'bg-info'}">${email.adStatus}</span>
            </td>
            <td>
                <span class="badge ${getPriorityClass(email.priority)}">${email.priority}</span>
                <br><small>${email.category}</small>
            </td>
            <td>
                <button class="btn btn-sm btn-outline-primary" onclick="viewEmail('${email.id}')">View</button>
                <button class="btn btn-sm btn-outline-success" onclick="markAsReadSingle('${email.id}')">Mark Read</button>
                <button class="btn btn-sm btn-outline-danger" onclick="deleteSingleEmail('${email.id}')">Delete</button>
            </td>
        `;
        
        tableBody.appendChild(row);
    });
}

// Show delete buttons for spam and ad emails
function showDeleteButtons() {
    const alertContainer = document.getElementById('alertContainer');
    
    const deleteButtonsHtml = `
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Spam/Ad Emails Detected!</strong> 
            Found ${spamEmailIds.length} emails that appear to be spam or advertisements.
            <div class="mt-2">
                <button class="btn btn-danger btn-sm" onclick="deleteAllSpamAndAds()">
                    <i class="bi bi-trash"></i> Delete All Spam & Ads
                </button>
                <button class="btn btn-warning btn-sm" onclick="markAllSpamAsRead()">
                    <i class="bi bi-check"></i> Mark All Spam as Read
                </button>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    alertContainer.innerHTML = deleteButtonsHtml;
}

// Delete all spam and ad emails
async function deleteAllSpamAndAds() {
    if (!confirm(`Are you sure you want to delete ${spamEmailIds.length} spam and ad emails? This action cannot be undone.`)) {
        return;
    }
    
    try {
        showLoading(true);
        showAlert('Deleting spam and ad emails...', 'info');
        
        // Delete emails in batches to avoid overwhelming the server
        const batchSize = 10;
        for (let i = 0; i < spamEmailIds.length; i += batchSize) {
            const batch = spamEmailIds.slice(i, i + batchSize);
            await deleteMultipleEmails(batch);
            updateProgress((i / spamEmailIds.length) * 100, `Deleting emails ${i + 1} to ${Math.min(i + batchSize, spamEmailIds.length)}`);
        }
        
        // Remove deleted emails from results
        emailResults = emailResults.filter(email => !spamEmailIds.includes(email.id));
        spamEmailIds = [];
        
        hideProgress();
        refreshTable();
        showAlert(`Successfully deleted ${spamEmailIds.length} spam and ad emails!`, 'success');
        
        // Hide delete buttons
        document.getElementById('alertContainer').innerHTML = '';
        
    } catch (error) {
        console.error('Delete all error:', error);
        showAlert(error.message || 'Error deleting emails', 'danger');
    } finally {
        hideLoading();
    }
}

// Mark all spam emails as read
async function markAllSpamAsRead() {
    try {
        showLoading(true);
        showAlert('Marking spam emails as read...', 'info');
        
        const spamEmails = emailResults.filter(email => 
            email.spamStatus === 'Spam' || email.adStatus === 'Ad'
        );
        
        for (let i = 0; i < spamEmails.length; i++) {
            await markEmailAsRead(spamEmails[i].id);
            updateProgress((i / spamEmails.length) * 100, `Marking email ${i + 1} as read`);
        }
        
        hideProgress();
        showAlert(`Successfully marked ${spamEmails.length} emails as read!`, 'success');
        
    } catch (error) {
        console.error('Mark all as read error:', error);
        showAlert(error.message || 'Error marking emails as read', 'danger');
    } finally {
        hideLoading();
    }
}

// Fixed CSV export function
function exportToCsv() {
    if (emailResults.length === 0) {
        showNotification('No data to export', 'info');
        return;
    }

    const headers = ['Date', 'From', 'Sender Email', 'Subject', 'Body', 'Category', 'Spam Status', 'Ad Status', 'Priority'];
    const csvContent = [
        headers.join(','),
        ...emailResults.map(email => [
            new Date(email.date).toISOString(),
            `"${email.from.replace(/"/g, '""')}"`,
            `"${email.senderEmail.replace(/"/g, '""')}"`,
            `"${email.subject.replace(/"/g, '""')}"`,
            `"${email.body.replace(/"/g, '""').replace(/\n/g, ' ').replace(/\r/g, '')}"`,
            email.category,
            email.spamStatus,
            email.adStatus,
            email.priority
        ].join(','))
    ].join('\n');

    // Create blob with proper encoding
    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    link.href = URL.createObjectURL(blob);
    link.download = `email-scan-results-${timestamp}.csv`;
    
    // Trigger download
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    // Clean up
    URL.revokeObjectURL(link.href);
    
    showNotification('CSV file exported successfully', 'success');
}

// Show loading
function showLoading(isLoading) {
    const loadingOverlay = document.getElementById('loadingOverlay');
    if (isLoading) {
        loadingOverlay.style.display = 'flex';
    } else {
        loadingOverlay.style.display = 'none';
    }
}

// Hide loading
function hideLoading() {
    const loadingOverlay = document.getElementById('loadingOverlay');
    if (loadingOverlay) {
        loadingOverlay.style.display = 'none';
    }
}

// Get priority class for styling
function getPriorityClass(priority) {
    switch (priority) {
        case 'High': return 'status-high';
        case 'Medium': return 'status-medium';
        default: return 'status-low';
    }
}

// Determine email priority based on content
function determinePriority(subject, body) {
    const urgentKeywords = ['urgent', 'important', 'asap', 'deadline', 'meeting'];
    const text = (subject + ' ' + body).toLowerCase();
    
    if (urgentKeywords.some(keyword => text.includes(keyword))) {
        return 'High';
    }
    
    // Check for time-sensitive words
    const timeKeywords = ['today', 'tomorrow', 'this week', 'due'];
    if (timeKeywords.some(keyword => text.includes(keyword))) {
        return 'Medium';
    }
    
    return 'Low';
}

// Determine email category
function determineCategory(subject, body) {
    const text = (subject + ' ' + body).toLowerCase();
    
    // Check for different categories
    if (text.includes('meeting') || text.includes('schedule') || text.includes('calendar')) {
        return 'Meeting';
    }
    if (text.includes('report') || text.includes('update') || text.includes('status')) {
        return 'Update';
    }
    if (text.includes('urgent') || text.includes('important') || text.includes('asap')) {
        return 'Urgent';
    }
    if (text.includes('newsletter') || text.includes('subscription')) {
        return 'Newsletter';
    }
    if (text.includes('notification') || text.includes('alert')) {
        return 'Notification';
    }
    
    return 'General';
}

// Show loading
function showLoading(isLoading) {
    const loadingOverlay = document.getElementById('loadingOverlay');
    if (isLoading) {
        loadingOverlay.style.display = 'flex';
    } else {
        loadingOverlay.style.display = 'none';
    }
}

// Show alert
function showAlert(message, type = 'info') {
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} mt-3`;
    alert.textContent = message;
    
    const alertContainer = document.getElementById('alertContainer');
    alertContainer.appendChild(alert);
    
    setTimeout(() => {
        alert.remove();
    }, 3000);
}

// Add progress indicator
function updateProgress(percentage, message) {
    let progressBar = document.getElementById('scanProgress');
    if (!progressBar) {
        progressBar = document.createElement('div');
        progressBar.id = 'scanProgress';
        progressBar.className = 'progress mt-3';
        progressBar.innerHTML = `
            <div class="progress-bar progress-bar-striped progress-bar-animated" 
                 role="progressbar" 
                 style="width: 0%" 
                 aria-valuenow="0" 
                 aria-valuemin="0" 
                 aria-valuemax="100">
                0%
            </div>
        `;
        document.querySelector('.card-body').insertBefore(
            progressBar,
            document.querySelector('.table-responsive')
        );
    }

    const progressBarInner = progressBar.querySelector('.progress-bar');
    progressBarInner.style.width = `${percentage}%`;
    progressBarInner.setAttribute('aria-valuenow', percentage);
    progressBarInner.textContent = `${percentage}%`;
}

function hideProgress() {
    const progressBar = document.getElementById('scanProgress');
    if (progressBar) {
        progressBar.remove();
    }
}

// Function to mark a single email as read
async function markAsReadSingle(emailId) {
    try {
        showLoading(true);
        await markEmailAsRead(emailId);
        
        // Update UI
        const row = document.querySelector(`tr[data-email-id="${emailId}"]`);
        if (row) {
            const statusCell = row.querySelector('td:nth-child(4)');
            statusCell.innerHTML = '<span class="badge bg-success">Read</span>';
        }
        
        showAlert('Email marked as read', 'success');
    } catch (error) {
        showAlert(error.message || 'Error marking email as read', 'danger');
    } finally {
        showLoading(false);
    }
}

// Function to delete a single email
async function deleteSingleEmail(emailId) {
    if (!confirm('Are you sure you want to delete this email?')) {
        return;
    }

    try {
        showLoading(true);
        await deleteEmail(emailId);
        
        // Update UI
        const row = document.querySelector(`tr[data-email-id="${emailId}"]`);
        if (row) {
            row.remove();
        }
        
        // Update email count
        const count = parseInt(document.getElementById('emailCount').textContent);
        document.getElementById('emailCount').textContent = count - 1;
        
        // Remove from results array
        emailResults = emailResults.filter(email => email.id !== emailId);
        
        showAlert('Email deleted', 'success');
    } catch (error) {
        showAlert(error.message || 'Error deleting email', 'danger');
    } finally {
        showLoading(false);
    }
}

// Update the sign in function
function signIn() {
    const email = document.getElementById('email').value;
    const appPassword = document.getElementById('password').value;

    // Clear any existing alerts
    const alertContainer = document.getElementById('alertContainer');
    alertContainer.innerHTML = '';

    // Validate inputs
    if (!email) {
        showAlert('Please enter your Gmail address', 'warning');
        return;
    }

    if (!email.includes('@gmail.com')) {
        showAlert('Please enter a valid Gmail address', 'warning');
        return;
    }

    if (!appPassword) {
        showAlert('Please enter your app password', 'warning');
        return;
    }

    showLoading(true);
    showAlert('Connecting to Gmail...', 'info');
    
    connectToGmail(email, appPassword)
        .then(() => {
            document.getElementById('loginForm').style.display = 'none';
            document.getElementById('scanButton').style.display = 'block';
            document.getElementById('signoutButton').style.display = 'block';
            showAlert('Successfully connected to Gmail', 'success');
        })
        .catch(error => {
            console.error('Sign in error:', error);
            showAlert(error.message || 'Error connecting to Gmail', 'danger');
        })
        .finally(() => {
            showLoading(false);
        });
}

// Sign out function
function signOut() {
    // Clear credentials
    userCredentials.email = '';
    userCredentials.appPassword = '';
    
    // Clear results
    emailResults = [];
    spamEmailIds = [];
    
    // Reset UI
    document.getElementById('loginForm').style.display = 'block';
    document.getElementById('scanButton').style.display = 'none';
    document.getElementById('signoutButton').style.display = 'none';
    document.getElementById('emailTable').style.display = 'none';
    document.getElementById('exportButton').style.display = 'none';
    document.getElementById('emailCount').textContent = '0';
    document.getElementById('alertContainer').innerHTML = '';
    
    // Clear form
    document.getElementById('email').value = '';
    document.getElementById('password').value = '';
    
    showAlert('Signed out successfully', 'info');
}

// Show notification
function showNotification(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    `;
    
    const toastContainer = document.getElementById('toastContainer') || document.body;
    toastContainer.appendChild(toast);
    
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
}

// Show loading spinner
function showSpinner() {
    const spinner = document.createElement('div');
    spinner.className = 'spinner-overlay';
    spinner.innerHTML = '<div class="spinner-border text-primary" role="status"></div>';
    document.body.appendChild(spinner);
}

// Hide loading spinner
function hideSpinner() {
    const spinner = document.querySelector('.spinner-overlay');
    if (spinner) {
        spinner.remove();
    }
}

// View email details
function viewEmail(emailId) {
    const email = emailResults.find(e => e.id === emailId);
    if (email) {
        const modal = new bootstrap.Modal(document.createElement('div'));
        modal.element.innerHTML = `
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">${email.subject}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <strong>From:</strong> ${email.from}<br>
                            <strong>Sender Email:</strong> ${email.senderEmail}<br>
                            <strong>Date:</strong> ${new Date(email.date).toLocaleString()}<br>
                            <strong>Status:</strong> 
                            <span class="badge ${email.spamStatus === 'Spam' ? 'bg-danger' : 'bg-success'}">${email.spamStatus}</span>
                            <span class="badge ${email.adStatus === 'Ad' ? 'bg-warning' : 'bg-info'}">${email.adStatus}</span>
                            <span class="badge ${getPriorityClass(email.priority)}">${email.priority}</span>
                        </div>
                        <div class="border p-3 bg-light">
                            <pre class="mb-0">${email.body}</pre>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-success" onclick="markAsReadSingle('${email.id}')" data-bs-dismiss="modal">
                            Mark as Read
                        </button>
                        <button type="button" class="btn btn-danger" onclick="deleteSingleEmail('${email.id}')" data-bs-dismiss="modal">
                            Delete
                        </button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal.element);
        modal.show();
        modal.element.addEventListener('hidden.bs.modal', () => {
            modal.element.remove();
        });
    }
} 