from flask import Flask, request, jsonify
from flask_cors import CORS
import imaplib
import email
from email.header import decode_header
import json
from datetime import datetime

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

def connect_to_gmail(email, app_password):
    try:
        # Connect to Gmail's IMAP server
        mail = imaplib.IMAP4_SSL("imap.gmail.com")
        mail.login(email, app_password)
        return mail
    except Exception as e:
        raise Exception(f"Connection failed: {str(e)}")

def fetch_unread_emails(mail):
    try:
        # Select the inbox
        mail.select("INBOX")
        
        # Search for unread emails
        _, messages = mail.search(None, "UNSEEN")
        email_list = []
        
        for num in messages[0].split():
            # Fetch email data
            _, msg_data = mail.fetch(num, "(RFC822)")
            email_body = msg_data[0][1]
            email_message = email.message_from_bytes(email_body)
            
            # Get subject
            subject = decode_header(email_message["subject"])[0][0]
            if isinstance(subject, bytes):
                subject = subject.decode()
            
            # Get sender
            sender = decode_header(email_message["from"])[0][0]
            if isinstance(sender, bytes):
                sender = sender.decode()
            
            # Get date
            date = email_message["date"]
            
            # Get body
            body = ""
            if email_message.is_multipart():
                for part in email_message.walk():
                    if part.get_content_type() == "text/plain":
                        try:
                            body = part.get_payload(decode=True).decode()
                        except:
                            body = "Unable to decode email body"
                        break
            else:
                try:
                    body = email_message.get_payload(decode=True).decode()
                except:
                    body = "Unable to decode email body"
            
            email_list.append({
                "id": num.decode(),
                "subject": subject,
                "sender": sender,
                "date": date,
                "body": body,
                "status": "unread"
            })
        
        return email_list
    except Exception as e:
        raise Exception(f"Error fetching emails: {str(e)}")

@app.route('/connect', methods=['POST'])
def connect():
    try:
        data = request.json
        email = data.get('email')
        app_password = data.get('app_password')
        
        if not email or not app_password:
            return jsonify({"error": "Email and app password are required"}), 400
        
        # Test connection
        mail = connect_to_gmail(email, app_password)
        mail.logout()
        
        return jsonify({"message": "Connection successful"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/scan', methods=['POST'])
def scan_emails():
    try:
        data = request.json
        email = data.get('email')
        app_password = data.get('app_password')
        
        if not email or not app_password:
            return jsonify({"error": "Email and app password are required"}), 400
        
        # Connect and fetch emails
        mail = connect_to_gmail(email, app_password)
        emails = fetch_unread_emails(mail)
        mail.logout()
        
        return jsonify({"emails": emails}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/mark-read', methods=['POST'])
def mark_as_read():
    try:
        data = request.json
        email = data.get('email')
        app_password = data.get('app_password')
        email_id = data.get('email_id')
        
        if not all([email, app_password, email_id]):
            return jsonify({"error": "Email, app password, and email ID are required"}), 400
        
        mail = connect_to_gmail(email, app_password)
        mail.select("INBOX")
        mail.store(email_id, '+FLAGS', '\\Seen')
        mail.logout()
        
        return jsonify({"message": "Email marked as read"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/delete', methods=['POST'])
def delete_email():
    try:
        data = request.json
        email = data.get('email')
        app_password = data.get('app_password')
        email_id = data.get('email_id')
        
        if not all([email, app_password, email_id]):
            return jsonify({"error": "Email, app password, and email ID are required"}), 400
        
        mail = connect_to_gmail(email, app_password)
        mail.select("INBOX")
        mail.store(email_id, '+FLAGS', '\\Deleted')
        mail.expunge()
        mail.logout()
        
        return jsonify({"message": "Email deleted"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/delete-multiple', methods=['POST'])
def delete_multiple_emails():
    try:
        data = request.json
        email = data.get('email')
        app_password = data.get('app_password')
        email_ids = data.get('email_ids', [])
        
        if not email or not app_password:
            return jsonify({"error": "Email and app password are required"}), 400
        
        if not email_ids or not isinstance(email_ids, list):
            return jsonify({"error": "Email IDs list is required"}), 400
        
        mail = connect_to_gmail(email, app_password)
        mail.select("INBOX")
        
        deleted_count = 0
        for email_id in email_ids:
            try:
                mail.store(email_id, '+FLAGS', '\\Deleted')
                deleted_count += 1
            except Exception as e:
                print(f"Error deleting email {email_id}: {str(e)}")
                continue
        
        # Expunge all deleted emails
        mail.expunge()
        mail.logout()
        
        return jsonify({
            "message": f"Successfully deleted {deleted_count} out of {len(email_ids)} emails",
            "deleted_count": deleted_count
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True, port=5000) 