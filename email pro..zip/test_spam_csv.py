#!/usr/bin/env python3
"""
Test script to verify spam.csv file access and processing
"""

import csv
import os

def test_spam_csv():
    """Test if spam.csv can be read and processed"""
    try:
        # Check if file exists
        if not os.path.exists('spam.csv'):
            print("❌ spam.csv file not found!")
            return False
        
        print("✅ spam.csv file found")
        
        # Try different encodings
        encodings = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
        
        for encoding in encodings:
            try:
                print(f"🔍 Trying encoding: {encoding}")
                
                # Read and count rows
                count = 0
                spam_count = 0
                ham_count = 0
                
                with open('spam.csv', 'r', encoding=encoding) as f:
                    reader = csv.reader(f)
                    
                    # Skip header if exists
                    first_row = next(reader)
                    if first_row and first_row[0] in ['v1', 'spam', 'ham']:
                        print(f"📋 Header row: {first_row}")
                    else:
                        # No header, process first row
                        if first_row and len(first_row) >= 2:
                            count += 1
                            if first_row[0] == 'spam':
                                spam_count += 1
                            elif first_row[0] == 'ham':
                                ham_count += 1
                    
                    # Process remaining rows
                    for row in reader:
                        if row and len(row) >= 2:
                            count += 1
                            if row[0] == 'spam':
                                spam_count += 1
                            elif row[0] == 'ham':
                                ham_count += 1
                
                print(f"📊 Total rows: {count}")
                print(f"🚨 Spam rows: {spam_count}")
                print(f"✅ Ham rows: {ham_count}")
                
                if spam_count > 0:
                    print(f"✅ Spam database loaded successfully with {encoding} encoding!")
                    return True
                else:
                    print("❌ No spam entries found in database")
                    return False
                    
            except UnicodeDecodeError:
                print(f"❌ Failed with {encoding} encoding")
                continue
            except Exception as e:
                print(f"❌ Error with {encoding} encoding: {e}")
                continue
        
        print("❌ Failed to read file with any encoding")
        return False
            
    except Exception as e:
        print(f"❌ Error reading spam.csv: {e}")
        return False

if __name__ == "__main__":
    print("🧪 Testing spam.csv file...")
    success = test_spam_csv()
    if success:
        print("🎉 All tests passed!")
    else:
        print("💥 Tests failed!") 