# Function to display menu
function Show-Menu {
    Clear-Host
    Write-Host "Gmail Email Scanner - PowerShell Launcher"
    Write-Host "====================================="
    Write-Host ""
    Write-Host "Choose an option:"
    Write-Host "1. Quick Start (Install & Run)"
    Write-Host "2. Install Requirements Only"
    Write-Host "3. Run Server Only"
    Write-Host "4. Check Python Installation"
    Write-Host "5. Check Port Availability"
    Write-Host "6. Clean Install (Remove old packages)"
    Write-Host "7. Exit"
    Write-Host ""
}

# Function to check Python installation
function Check-PythonInstallation {
    Write-Host "`nChecking Python installation..."
    try {
        $pythonVersion = python --version
        Write-Host "Python is installed: $pythonVersion"
    }
    catch {
        Write-Host "Python is not installed or not in PATH!"
        Write-Host "Please install Python from https://www.python.org/downloads/"
    }

    Write-Host "`nChecking pip installation..."
    try {
        $pipVersion = pip --version
        Write-Host "pip is installed: $pipVersion"
    }
    catch {
        Write-Host "pip is not installed or not in PATH!"
    }
    Read-Host "Press Enter to continue"
}

# Function to check port availability
function Check-PortAvailability {
    Write-Host "`nChecking if port 5000 is available..."
    $portInUse = Get-NetTCPConnection -LocalPort 5000 -ErrorAction SilentlyContinue
    if ($portInUse) {
        Write-Host "Port 5000 is in use!"
        Write-Host "Please close any applications using port 5000."
    }
    else {
        Write-Host "Port 5000 is available!"
    }
    Read-Host "Press Enter to continue"
}

# Function to clean install
function Clean-Install {
    Write-Host "`nRemoving old packages..."
    pip uninstall -y flask flask-cors werkzeug python-dotenv imaplib2 email-validator
    
    Write-Host "`nInstalling fresh requirements..."
    pip install -r requirements.txt
    if ($LASTEXITCODE -eq 0) {
        Write-Host "Clean install completed successfully!"
    }
    else {
        Write-Host "Error during clean install!"
    }
    Read-Host "Press Enter to continue"
}

# Main menu loop
while ($true) {
    Show-Menu
    $choice = Read-Host "Enter your choice (1-7)"
    
    switch ($choice) {
        "1" {
            Write-Host "`nInstalling requirements..."
            pip install -r requirements.txt
            if ($LASTEXITCODE -eq 0) {
                Write-Host "`nStarting server..."
                Start-Process "http://localhost:5000"
                python server.py
            }
            else {
                Write-Host "Error installing requirements!"
                Read-Host "Press Enter to continue"
            }
        }
        "2" {
            Write-Host "`nInstalling requirements..."
            pip install -r requirements.txt
            if ($LASTEXITCODE -eq 0) {
                Write-Host "Requirements installed successfully!"
            }
            else {
                Write-Host "Error installing requirements!"
            }
            Read-Host "Press Enter to continue"
        }
        "3" {
            Write-Host "`nStarting server..."
            Start-Process "http://localhost:5000"
            python server.py
        }
        "4" {
            Check-PythonInstallation
        }
        "5" {
            Check-PortAvailability
        }
        "6" {
            Clean-Install
        }
        "7" {
            Write-Host "Exiting..."
            exit
        }
        default {
            Write-Host "Invalid option!"
            Read-Host "Press Enter to continue"
        }
    }
} 