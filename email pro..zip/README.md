# Gmail Email Scanner

A web application to scan and manage your Gmail unread emails.

## Setup Instructions

### Prerequisites
1. Python 3.8 or higher
2. A Gmail account
3. Gmail App Password (see below)

### Getting a Gmail App Password
1. Go to your Google Account settings (https://myaccount.google.com)
2. Navigate to Security
3. Enable 2-Step Verification if not already enabled
4. Go to App Passwords
5. Select "Mail" and your device
6. Generate and copy the 16-character app password

### Installation

#### Method 1: Using run.bat (Recommended for Windows)
1. Double-click `run.bat`
2. Wait for the server to start
3. Open `index.html` in your web browser

#### Method 2: Manual Setup
1. Open Command Prompt
2. Navigate to the project directory:
   ```bash
   cd "path\to\Email & SMS"
   ```
3. Install requirements:
   ```bash
   pip install -r requirements.txt
   ```
4. Start the server:
   ```bash
   python server.py
   ```
5. Open `index.html` in your web browser

## Using the Application

1. Enter your Gmail address
2. Enter your Gmail app password
3. Click "Connect to Gmail"
4. Once connected, click "Scan Unread Emails"
5. View and manage your emails:
   - Mark emails as read
   - Delete emails
   - Export to CSV

## Troubleshooting

### Common Issues

1. **Server won't start**
   - Make sure Python is installed
   - Check if port 5000 is available
   - Try running as administrator

2. **Can't connect to Gmail**
   - Verify your app password is correct
   - Make sure 2-Step Verification is enabled
   - Check your internet connection

3. **No emails showing**
   - Verify you have unread emails
   - Check if you're using the correct Gmail account
   - Try refreshing the page

### Getting Help
If you encounter any issues:
1. Check the console (F12) for error messages
2. Make sure the Python server is running
3. Verify all files are in the correct directory

## Files in the Project
- `server.py` - Python backend server
- `index.html` - Web interface
- `script.js` - Frontend JavaScript
- `styles.css` - Styling
- `requirements.txt` - Python dependencies
- `run.bat` - Windows startup script 