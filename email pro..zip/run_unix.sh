#!/bin/bash

# Function to display menu
show_menu() {
    clear
    echo "Gmail Email Scanner - Unix Launcher"
    echo "================================"
    echo
    echo "Choose an option:"
    echo "1. Quick Start (Install & Run)"
    echo "2. Install Requirements Only"
    echo "3. Run Server Only"
    echo "4. Check Python Installation"
    echo "5. Check Port Availability"
    echo "6. Clean Install (Remove old packages)"
    echo "7. Exit"
    echo
}

# Function to check Python installation
check_python() {
    echo
    echo "Checking Python installation..."
    if command -v python3 &>/dev/null; then
        python3 --version
        echo "Python is installed correctly."
    else
        echo "Python is not installed!"
        echo "Please install Python using your system's package manager:"
        echo "Ubuntu/Debian: sudo apt-get install python3 python3-pip"
        echo "Mac: brew install python3"
        echo "CentOS/RHEL: sudo yum install python3 python3-pip"
    fi
    
    echo
    echo "Checking pip installation..."
    if command -v pip3 &>/dev/null; then
        pip3 --version
        echo "pip is installed correctly."
    else
        echo "pip is not installed!"
    fi
    read -p "Press Enter to continue..."
}

# Function to check port availability
check_port() {
    echo
    echo "Checking if port 5000 is available..."
    if command -v netstat &>/dev/null; then
        if netstat -tuln | grep -q ":5000 "; then
            echo "Port 5000 is in use!"
            echo "Please close any applications using port 5000."
        else
            echo "Port 5000 is available!"
        fi
    elif command -v lsof &>/dev/null; then
        if lsof -i :5000 &>/dev/null; then
            echo "Port 5000 is in use!"
            echo "Please close any applications using port 5000."
        else
            echo "Port 5000 is available!"
        fi
    else
        echo "Could not check port availability. Please install net-tools or lsof."
    fi
    read -p "Press Enter to continue..."
}

# Function to clean install
clean_install() {
    echo
    echo "Removing old packages..."
    pip3 uninstall -y flask flask-cors werkzeug python-dotenv imaplib2 email-validator
    
    echo
    echo "Installing fresh requirements..."
    pip3 install -r requirements.txt
    if [ $? -eq 0 ]; then
        echo "Clean install completed successfully!"
    else
        echo "Error during clean install!"
    fi
    read -p "Press Enter to continue..."
}

# Main menu loop
while true; do
    show_menu
    read -p "Enter your choice (1-7): " choice
    
    case $choice in
        1)
            echo
            echo "Installing requirements..."
            pip3 install -r requirements.txt
            if [ $? -eq 0 ]; then
                echo
                echo "Starting server..."
                if command -v xdg-open &>/dev/null; then
                    xdg-open http://localhost:5000 &
                elif command -v open &>/dev/null; then
                    open http://localhost:5000 &
                fi
                python3 server.py
            else
                echo "Error installing requirements!"
                read -p "Press Enter to continue..."
            fi
            ;;
        2)
            echo
            echo "Installing requirements..."
            pip3 install -r requirements.txt
            if [ $? -eq 0 ]; then
                echo "Requirements installed successfully!"
            else
                echo "Error installing requirements!"
            fi
            read -p "Press Enter to continue..."
            ;;
        3)
            echo
            echo "Starting server..."
            if command -v xdg-open &>/dev/null; then
                xdg-open http://localhost:5000 &
            elif command -v open &>/dev/null; then
                open http://localhost:5000 &
            fi
            python3 server.py
            ;;
        4)
            check_python
            ;;
        5)
            check_port
            ;;
        6)
            clean_install
            ;;
        7)
            echo "Exiting..."
            exit 0
            ;;
        *)
            echo "Invalid option!"
            read -p "Press Enter to continue..."
            ;;
    esac
done 